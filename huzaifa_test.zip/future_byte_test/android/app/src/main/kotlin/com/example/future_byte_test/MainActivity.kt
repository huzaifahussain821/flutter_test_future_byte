package com.example.future_byte_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
