import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:future_byte_test/widgets/text_widget/custom_text_widget.dart';

import '../../utils/theme/app_colors.dart';

class CustomButton extends StatelessWidget {
  final String? text;
  final Color? textColor;
  final Color? backgroundColor;
  final Function() onTap;
  final Widget icon;
  final double? textSize;
  final FontWeight? textWeight;
  final Color? borderColor;
  final double? borderSize;
  final double? paddingVertical;
  final double? paddingHorizontal;
  final double? buttonRadius;
  final double? iconTextGap;
  final double? buttonWidth;
  final double? buttonHeight;
  final double? iconTextWidth;
  final bool? iconShow;
  final bool? onlyRightSideRadius, onlyLeftSideRadius, noRadius;

  CustomButton(
      {super.key,
      required this.text,
      this.textColor,
      this.buttonWidth,
      this.buttonHeight,
      required this.onTap,
      this.backgroundColor,
      this.iconTextWidth = 10,
      this.icon = const SizedBox.shrink(),
      this.textSize,
      this.iconShow = false,
      this.textWeight,
      this.borderColor,
      this.borderSize,
      this.paddingHorizontal = 0,
      this.paddingVertical,
      this.buttonRadius,
      this.iconTextGap,
      this.onlyLeftSideRadius = false,
      this.onlyRightSideRadius = false,
      this.noRadius = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: buttonHeight,
        width: buttonWidth??double.infinity,
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: onlyLeftSideRadius == true
              ? const BorderRadius.only(
                  bottomLeft: Radius.circular(10), topLeft: Radius.circular(10))
              : onlyRightSideRadius == true
                  ? const BorderRadius.only(
                      bottomRight: Radius.circular(10),
                      topRight: Radius.circular(10))
                  : noRadius == true
                      ? null
                      : BorderRadius.circular(10),
          border: Border.all(
            color: borderColor ?? AppColors.transparentColor,
            width: 1,
          ),
        ),
        padding: const EdgeInsets.symmetric(
          vertical: 10,
          horizontal: 10,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            iconShow == true
                ? Row(
                    children: [
                      icon,
                      iconTextWidth!.horizontalSpace,
                    ],
                  )
                : const SizedBox(),
            CustomTextWidget(
              text: text,
              textColor: textColor,
              textSize: textSize,
              fontWeight: textWeight ?? FontWeight.bold,
              textOverflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
