import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:future_byte_test/utils/theme/app_colors.dart';
import 'package:future_byte_test/widgets/text_widget/custom_text_widget.dart';

class BarChart extends StatefulWidget {
  const BarChart(
      {super.key,
      required this.daysPerWeek,
      required this.graphData,
      this.leftTitle,
      this.bottomTitle});
  final List<String> daysPerWeek;
  final List<int> graphData;
  final String? leftTitle;
  final String? bottomTitle;

  @override
  State<BarChart> createState() => _BarChartState();
}

class _BarChartState extends State<BarChart> {
  late final height = MediaQuery.of(context).size.height;
  late final width = MediaQuery.of(context).size.width;
  late int maximumValue =
      widget.graphData.reduce((curr, next) => curr > next ? curr : next);
  late int minimumValue =
      widget.graphData.reduce((curr, next) => curr < next ? curr : next);
  late double containerHeight =
      (widget.graphData.length * (maximumValue)).toDouble();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          EdgeInsets.symmetric(vertical: width * .03, horizontal: width * .01),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: Colors.grey.shade100, width: 3)),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              _legendWidget(color: AppColors.pinkColor, text: "Absents"),
              10.horizontalSpace,
              _legendWidget(color: AppColors.yellowColow, text: "Late"),
              10.horizontalSpace,
              _legendWidget(color: AppColors.greenColor, text: "On-time")
            ],
          ),
          20.verticalSpace,
          _barWidget(),
          if ((widget.bottomTitle ?? "").isNotEmpty)
            Padding(
                padding: EdgeInsets.only(top: .03 * width),
                child: CustomTextWidget(
                  text: widget.bottomTitle ?? "",
                  textSize: 1.sp,
                  textColor: AppColors.greyNormalColor,
                )),
        ],
      ),
    );
  }

  Widget _barWidget() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        leftLabels(),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (int i = 0; i < widget.daysPerWeek.length; i++)
              SizedBox(
                width: .09 * width,
                height: containerHeight + 60,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Spacer(),
                    ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Column(children: [
                          for (int j = 0; j < widget.graphData[i]; j++)
                            Container(
                                width: 12,
                                height:
                                    (containerHeight / widget.graphData.length),
                                decoration: BoxDecoration(
                                    color: widget.graphData[i] < 5
                                        ? AppColors.pinkColor
                                        : widget.graphData[i] == 10
                                            ? AppColors.greenColor
                                            : AppColors.yellowColow))
                        ])),
                    Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: CustomTextWidget(
                          text: widget.daysPerWeek[i],
                          textColor: AppColors.greyNormalColor,
                          textSize: 0.8.sp,
                        )),
                  ],
                ),
              )
          ],
        ),
      ],
    );
  }

  Widget leftLabels() {
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if ((widget.leftTitle ?? "").isNotEmpty)
            Padding(
              padding: EdgeInsets.only(right: .04 * width),
              child: RotatedBox(
                  quarterTurns: 3,
                  child: CustomTextWidget(
                    text: widget.leftTitle ?? "",
                    textSize: 1.sp,
                    textColor: AppColors.greyNormalColor,
                  )),
            ),
          SizedBox(
            height: containerHeight + 55,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              mainAxisSize: MainAxisSize.min,
              children: [
                for (int i = maximumValue; i >= minimumValue; i--)
                  if (i % (maximumValue ~/ 4) == 0)
                    CustomTextWidget(
                      text: i.toString(),
                      textColor: AppColors.greyNormalColor,
                      textSize: 0.8.sp,
                    )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _legendWidget({Color? color, String? text}) {
    return Row(
      children: [
        Container(
          height: 8,
          width: 8,
          decoration: BoxDecoration(
              color: color ?? AppColors.redColor, shape: BoxShape.circle),
        ),
        10.horizontalSpace,
        CustomTextWidget(
          text: text ?? "",
          textColor: AppColors.greyNormalColor,
          textSize: 0.9.sp,
        )
      ],
    );
  }
}
