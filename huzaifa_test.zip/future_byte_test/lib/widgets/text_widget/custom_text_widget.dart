import 'package:flutter/material.dart';
import 'package:future_byte_test/utils/contants/app_strings.dart';
import '../../utils/theme/app_colors.dart';

class CustomTextWidget extends StatelessWidget {
  final String? text, fontFamily;
  final Color? textColor;
  final double? textSize, textHeight, decorationThickness;
  final FontWeight? fontWeight;
  final int? maxLines;
  final TextOverflow? textOverflow;
  final TextAlign? textAlign;
  final TextDecoration? textDecoration;

  CustomTextWidget(
      {this.text,
      this.textColor,
      this.textSize,
      this.fontFamily,
      this.fontWeight,
      this.maxLines,
      this.textOverflow,
      this.textAlign,
      this.textHeight,
      this.textDecoration,
      this.decorationThickness});

  @override
  Widget build(BuildContext context) {
    return Text(
      text ?? "",
      style: TextStyle(
        color: textColor ?? AppColors.whiteColor,
        fontWeight: fontWeight ?? FontWeight.w400,
        height: textHeight,
        fontFamily: AppStrings.interFontFamily,
        decoration: textDecoration ?? TextDecoration.none,
        decorationThickness: decorationThickness ?? 0.0,
      ),
      textScaler:  TextScaler.linear(textSize ?? 1.0)     ,
      maxLines: maxLines??1,
      overflow: textOverflow??TextOverflow.ellipsis,
      textAlign: textAlign ?? TextAlign.start,
    );
  }
}
