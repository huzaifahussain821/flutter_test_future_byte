import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../utils/asset_paths/assets_path.dart';
import '../../utils/theme/app_colors.dart';

class CustomAppBarWidget extends StatelessWidget
    implements PreferredSizeWidget {
  List<String?> actionIconsList;
  CustomAppBarWidget({super.key, required this.actionIconsList});
  @override
  Size get preferredSize => const Size.fromHeight(65);
  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: AppColors.transparentColor,
      elevation: 0,
      title: Image.asset(
        AssetPaths.logoImage,
        fit: BoxFit.contain,
        scale: 18,
      ),
      toolbarHeight: 50.h,
      actions: List.generate(
          actionIconsList?.length ?? 0,
          (index) => Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Image.asset(
                  actionIconsList[index] ?? "",
                  scale: 2.8,
                ),
          )),
    );
  }
}
