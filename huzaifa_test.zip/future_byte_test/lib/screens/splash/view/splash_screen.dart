import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:future_byte_test/utils/route_manager/app_route_name.dart';

import '../../../utils/asset_paths/assets_path.dart';
import '../../../utils/navigation/app_navigation.dart';
import '../../../utils/theme/app_colors.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _splashTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.whiteColor,
      body: Container(
        color: AppColors.whiteColor,
        width: double.infinity,
        height: double.infinity,
        child: Image.asset(
          AssetPaths.logoImage,
          scale: 7,
        ),
      ),
    );
  }

  Future<Timer> _splashTimer() async {
    return Timer(const Duration(seconds: 3), _onComplete);
  }

  void _onComplete() {
    AppNavigation.navigateReplacementNamed(context, AppRouteName.homeScreenRoute);
  }
}
