import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:future_byte_test/screens/home/widgets/stats_widget.dart';
import 'package:future_byte_test/utils/asset_paths/assets_path.dart';
import 'package:future_byte_test/utils/contants/app_strings.dart';
import 'package:future_byte_test/utils/theme/app_colors.dart';
import 'package:future_byte_test/widgets/text_widget/custom_text_widget.dart';
import '../../../widgets/appbar_widget/appbar_widget.dart';
import '../../../widgets/button_widget/custom_button_widget.dart';
import '../widgets/attendance_summary_widget.dart';
import '../widgets/header_widget.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBarWidget(
        actionIconsList: const [
          AssetPaths.notificationIcon,
          AssetPaths.chatIcon,
          AssetPaths.menuIcon
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const HeaderWidget(),
              40.verticalSpace,
              StatsWidget(
                mainHeading: AppStrings.welcomeBack,
                subHeading: AppStrings.takeALook,
              ),
              40.verticalSpace,
               const AttendanceSummaryWidget(),
              40.verticalSpace
            ],
          ),
        ),
      ),
    );
  }
}
