import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:future_byte_test/screens/home/widgets/percentage_widget.dart';

import '../../../utils/asset_paths/assets_path.dart';
import '../../../utils/theme/app_colors.dart';
import '../../../widgets/text_widget/custom_text_widget.dart';

class StatsDetailWidget extends StatelessWidget {
  String? heading, text1, text2, text3, text4;
  bool? showPercentage, showGreenStatus;
  StatsDetailWidget(
      {super.key,
      this.text1,
      this.text2,
      this.heading,
      this.text4,
      this.text3,
      this.showPercentage = true,
      this.showGreenStatus});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomTextWidget(
          text: heading ?? "",
          textSize: 1.1.sp,
          fontWeight: FontWeight.bold,
          textColor: AppColors.whiteColor,
          textOverflow: TextOverflow.ellipsis,
        ),
        Divider(
          color: AppColors.whiteColor,
          thickness: 1,
        ),
        Row(
          children: [
            Expanded(
                child: _subheading(
                    text1: text1,
                    text2: text2,
                    showPercentage: showPercentage)),
            10.horizontalSpace,
            Expanded(
                child: _subheading(
                    text1: text3,
                    text2: text4,
                    showPercentage: showPercentage)),
          ],
        )
      ],
    );
  }

  Widget _subheading({
    String? text1,
    String? text2,
    bool? showPercentage = true,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomTextWidget(
          text: text1 ?? "",
          textSize: 1.1.sp,
          fontWeight: FontWeight.bold,
          textColor: AppColors.whiteColor,
          textOverflow: TextOverflow.ellipsis,
        ),
        10.verticalSpace,
        CustomTextWidget(
          text: text2 ?? "",
          textSize: 0.9.sp,
          maxLines: 2,
          textColor: AppColors.whiteColor,
        ),
        5.verticalSpace,
        showPercentage == true
            ? PercentageWidget(
                showGreenStatus: showGreenStatus,
              )
            : const SizedBox()
      ],
    );
  }
}
