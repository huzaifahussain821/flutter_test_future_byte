import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../utils/theme/app_colors.dart';
import '../../../widgets/button_widget/custom_button_widget.dart';

class TabbarWidget extends StatelessWidget {
   TabbarWidget({super.key});
  final ValueNotifier<int> currentIndex = ValueNotifier<int>(0);
  final List<String> _summaryList = ["Today", "This Week", "This Month"];
  @override
  Widget build(BuildContext context) {
    return  ValueListenableBuilder<int>(
        valueListenable: currentIndex,
        builder: (context, int value, child) {
          return SizedBox(
            height: 40,
            child: ListView.builder(
                shrinkWrap: true,
                itemCount: _summaryList?.length ?? 0,
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index) {
                  return CustomButton(
                    text: _summaryList[index] ?? '',
                    onTap: () {
                      currentIndex.value=index;
                    },
                    buttonWidth: index == 0 ? 70.w : 90.w,
                    buttonHeight: 40,
                    onlyLeftSideRadius: index == 0 ? true : false,
                    noRadius: index == 1 ? true : false,
                    onlyRightSideRadius: index == 2 ? true : false,
                    iconShow: false,
                    textColor: currentIndex.value==index? AppColors.orangeColor :AppColors.greyDarkColor,
                    borderColor: AppColors.greyLightColor,
                  );
                }),
          );
        });
  }
}
