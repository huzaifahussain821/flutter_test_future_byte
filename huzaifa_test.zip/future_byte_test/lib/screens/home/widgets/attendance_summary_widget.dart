import 'package:flutter/cupertino.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:future_byte_test/screens/home/widgets/tabbar_widget.dart';
import 'package:future_byte_test/utils/contants/app_strings.dart';
import 'package:future_byte_test/widgets/chart/bar_chart/bar_chart.dart';

import '../../../utils/asset_paths/assets_path.dart';
import '../../../utils/theme/app_colors.dart';
import '../../../widgets/button_widget/custom_button_widget.dart';
import '../../../widgets/text_widget/custom_text_widget.dart';

class AttendanceSummaryWidget extends StatelessWidget {
  const AttendanceSummaryWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _summaryHeaderWidget(),  15.verticalSpace,
        TabbarWidget(),
        10.verticalSpace,
        const BarChart(
          daysPerWeek: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun",],
          graphData: [7, 5, 10, 3, 7, 6, 4],
          leftTitle: "Attendance",
          bottomTitle: "This Week",
        ),
        10.verticalSpace,
        _learnMoreFooterWidget()
      ],
    );
  }

  Widget _summaryHeaderWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        CustomTextWidget(
          text: AppStrings.attendanceSummary,
          textSize: 1.1.sp,
          fontWeight: FontWeight.bold,
          textColor: AppColors.blackColor,
          textOverflow: TextOverflow.ellipsis,
        ),
        Image.asset(
          AssetPaths.moreVertIcon,
          scale: 3,
        )
      ],
    );
  }

  Widget _learnMoreFooterWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        CustomTextWidget(
          text: AppStrings.learnMore,
          textSize: 0.9.sp,
          fontWeight: FontWeight.bold,
          textColor: AppColors.greyNormalColor,
          textOverflow: TextOverflow.ellipsis,
        ),
        CustomButton(
          text: AppStrings.viewFullReport,
          onTap: () {},
          buttonWidth: 150.w,
          iconShow: false,
          textColor: AppColors.greyDarkColor,
          borderColor: AppColors.greyLightColor,
        ),
      ],
    );
  }


}
