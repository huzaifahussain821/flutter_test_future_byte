import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../utils/asset_paths/assets_path.dart';
import '../../../utils/theme/app_colors.dart';
import '../../../widgets/button_widget/custom_button_widget.dart';
import '../../../widgets/text_widget/custom_text_widget.dart';

class HeaderWidget extends StatelessWidget {
  const HeaderWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomTextWidget(
          text: "Organization Insights.",
          textSize: 1.2.sp,
          fontWeight: FontWeight.bold,
          textColor: AppColors.greyHeadingColor,
        ),
        3.verticalSpace,
        CustomTextWidget(
          text: "Track Your Organization Stats Insights",
          textSize: 0.9.sp,
          textColor: AppColors.greyNormalColor,
        ),
        20.verticalSpace,
        CustomButton(
          text: 'Manage Widget',
          onTap: () {},
          buttonWidth: 150.w,
          iconShow: true,
          icon: Image.asset(
            AssetPaths.addIcon,
            scale: 3,
          ),
          textColor: AppColors.greyDarkColor,
          borderColor: AppColors.greyLightColor,
        ),
      ],
    );
  }
}
