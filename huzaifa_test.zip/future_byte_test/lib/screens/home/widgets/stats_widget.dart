import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:future_byte_test/screens/home/widgets/stats_detail_widget.dart';
import 'package:future_byte_test/utils/contants/app_strings.dart';

import '../../../utils/asset_paths/assets_path.dart';
import '../../../utils/theme/app_colors.dart';
import '../../../widgets/button_widget/custom_button_widget.dart';
import '../../../widgets/text_widget/custom_text_widget.dart';

class StatsWidget extends StatelessWidget {
  String? mainHeading, subHeading;
  StatsWidget({super.key, this.mainHeading, this.subHeading});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
          color: AppColors.blueColor, borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomTextWidget(
                      text: mainHeading ?? "",
                      textSize: 1.1.sp,
                      fontWeight: FontWeight.bold,
                      textColor: AppColors.whiteColor,
                      textOverflow: TextOverflow.ellipsis,
                    ),
                    5.verticalSpace,
                    CustomTextWidget(
                      text: subHeading ?? "",
                      textSize: 0.9.sp,
                      textColor: AppColors.whiteColor,
                    ),
                  ],
                ),
                CustomButton(
                  text: "",
                  onTap: () {},
                  buttonHeight: 40,
                  buttonWidth: 40,
                  iconTextWidth: 0,
                  backgroundColor: AppColors.whiteColor,
                  iconShow: true,
                  icon: Image.asset(
                    AssetPaths.shareIcon,
                    scale: 3,
                  ),
                )
              ],
            ),
            10.verticalSpace,
            StatsDetailWidget(
              heading: AppStrings.averageLateOvertTime,
              text1: "25 min",
              text2: AppStrings.avgLateness,
              text3: "5 hr 15 min",
              text4: AppStrings.avgLaOvertime,
             showGreenStatus: false,
            ),
            20.verticalSpace,
            StatsDetailWidget(
              heading: AppStrings.payrollFinance,
              text1: "AED 43.20K",
              text2: AppStrings.totalProcessed,
              text3: "AED 105.40K",
              text4: AppStrings.avgProcessed,
            showGreenStatus: true,
            ),
            20.verticalSpace,
            Row(
              children: [
                Expanded(
                    child: StatsDetailWidget(
                  heading: AppStrings.activity,
                  text1: "22",
                  text2: AppStrings.avgLeaves,
                  text3: "70",
                  text4: AppStrings.avgAttendance,
                  showPercentage: false,
                )),
                20.horizontalSpace,
                Expanded(
                    child: StatsDetailWidget(
                  heading: AppStrings.headCount,
                  text1: "1283",
                  text2: AppStrings.totalEmployees,
                  text3: "250",
                  text4: AppStrings.totalInternships,
                  showPercentage: false,
                )),
              ],
            )
          ],
        ),
      ),
    );
  }
}
