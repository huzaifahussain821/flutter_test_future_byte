import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../utils/asset_paths/assets_path.dart';
import '../../../utils/theme/app_colors.dart';
import '../../../widgets/text_widget/custom_text_widget.dart';

class PercentageWidget extends StatelessWidget {
  bool? showRedStatus, showGreenStatus;
  PercentageWidget({
    super.key,
    this.showRedStatus,
    this.showGreenStatus,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 70,
      decoration: BoxDecoration(
          color: AppColors.whiteColor,
          border: Border.all(
              color: showRedStatus == false || showGreenStatus == false
                  ? AppColors.redColor
                  : AppColors.greenColor,
              width: 1),
          borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(4.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
             showGreenStatus==false? AssetPaths.downArrowIcon:AssetPaths.upArrowIcon,
              scale: 2.5,
            ),
            10.horizontalSpace,
            CustomTextWidget(
              text: "15%",
              textColor: showGreenStatus==false? AppColors.redColor:AppColors.greenColor,
              textSize: 0.8.sp,
            )
          ],
        ),
      ),
    );
  }
}
