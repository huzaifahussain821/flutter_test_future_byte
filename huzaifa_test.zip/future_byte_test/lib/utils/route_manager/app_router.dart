import 'package:flutter/material.dart';
import 'package:future_byte_test/screens/home/view/home_screen.dart';
import '../../screens/splash/view/splash_screen.dart';
import 'app_route_name.dart';

class AppRouter {
  Route onGenerateRoute(RouteSettings routeSettings) {
    return MaterialPageRoute(
        settings: routeSettings,
        builder: (BuildContext context) {
          switch (routeSettings.name) {
            case AppRouteName.splashRoute:
              return SplashScreen();
            case AppRouteName.homeScreenRoute:
              return const HomeScreen();

            default:
              return Container();
          }
        });
  }
}
