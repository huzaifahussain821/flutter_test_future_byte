class AppRouteName {
  //--------------------- BASIC SCREEN ROUTES ------------------------//
  static const String splashRoute = "/";
  static const String homeScreenRoute = "homeScreenRoute";

}
