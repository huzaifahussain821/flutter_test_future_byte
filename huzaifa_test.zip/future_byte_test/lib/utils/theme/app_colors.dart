import 'package:flutter/material.dart';

class AppColors {
  static Color redColor = const Color(0xFFDF1A23);
  static Color whiteColor = const Color(0xFFFFFFFF);
  static Color blackColor = const Color(0xFF000000);
  static Color greenColor = const Color(0xFF14B70F);
  static Color greyLightColor = const Color(0xFFD0D5DD);
  static Color greyNormalColor = const Color(0xFF475467);
  static Color greyDarkColor = const Color(0xFF344054);
  static Color greyHeadingColor = const Color(0xFF101828);
  static Color blueColor = const Color(0xFF1E5BD7);
  static Color orangeColor = const Color(0xFFE55511);
  static Color pinkColor = const Color(0xFFFD6C6C);
  static Color yellowColow = const Color(0xFFFFC107);
  static Color transparentColor = Colors.transparent;
}
