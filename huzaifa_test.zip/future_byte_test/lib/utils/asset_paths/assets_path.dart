class AssetPaths {
  static const String imagePath = "assets/logo";
  static const String iconsPath = "assets/icons";

  //----------- IMAGES---------//
  static const String logoImage = "$imagePath/logo.png";


  //------------ ICONS ------------ //
  static const String addIcon = "$iconsPath/add.png";
  static const String chatIcon = "$iconsPath/chat.png";
  static const String downArrowIcon = "$iconsPath/down_arrow.png";
  static const String menuIcon = "$iconsPath/menu.png";
  static const String moreVertIcon = "$iconsPath/more_vert.png";
  static const String notificationIcon = "$iconsPath/notification.png";
  static const String shareIcon = "$iconsPath/share.png";
  static const String upArrowIcon = "$iconsPath/up_arrow.png";

}
