class AppStrings {
  static const String appTitleText = "Eazio";

  static const String interFontFamily = "Inter";
  static const String welcomeBack = "Welcome Back, John!";
  static const String takeALook = "Take A Look at Our Weekly Reports.";
  static const String averageLateOvertTime = "Average Late & Overtime";
  static const String avgLateness = "Avg. Lateness";
  static const String avgLaOvertime = "Avg. Overtime";
  static const String payrollFinance = "Payroll Finance";
  static const String totalProcessed = "Total Processed";
  static const String avgProcessed = "Avg. Processed";
  static const String activity = "Activity";
  static const String avgLeaves = "Avg. Leaves";
  static const String avgAttendance = "Avg. Attendance";
  static const String headCount = "Head Count";
  static const String totalEmployees = "Total Employees";
  static const String totalInternships = "Total Internships";
  static const String attendanceSummary = "Attendance Summary";
  static const String learnMore = "Learn More";
  static const String viewFullReport = "View full More";


}
